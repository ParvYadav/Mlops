from setuptools import setup, find_packages

setup(
    name = 'src',
    version = '0.0.1',
    description = 'Mlops for wineq',
    author = 'Parv Yadav',
    package = find_packages(),
    license = 'MIT'
    )